<?php
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/VotingEngine.php';

class AdminController {

    public function dashboard() {
        Auth::requireAuth();
        Auth::requireAdmin();
        $db = getDB();
        
        $totalPolls = $db->query("SELECT COUNT(*) FROM polls")->fetchColumn();
        $activePolls = $db->query("SELECT COUNT(*) FROM polls WHERE status='active'")->fetchColumn();
        $totalVotes = $db->query("SELECT COUNT(*) FROM votes WHERE is_active=1")->fetchColumn();
        $totalUsers = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();

        $recentPolls = $db->query(
            "SELECT p.*, (SELECT COUNT(*) FROM votes v WHERE v.poll_id=p.id AND v.is_active=1) as vote_count
             FROM polls p ORDER BY p.created_at DESC LIMIT 5"
        )->fetchAll();

        $user = Auth::user();
        require VIEWS_PATH . 'admin/dashboard.php';
    }

    public function polls() {
        Auth::requireAuth();
        Auth::requireAdmin();
        $db = getDB();
        $polls = $db->query(
            "SELECT p.*, u.name as creator_name,
             (SELECT COUNT(*) FROM votes v WHERE v.poll_id=p.id AND v.is_active=1) as vote_count
             FROM polls p LEFT JOIN users u ON p.created_by=u.id
             ORDER BY p.created_at DESC"
        )->fetchAll();

        $user = Auth::user();
        require VIEWS_PATH . 'admin/polls.php';
    }

    public function createPoll() {
        Auth::requireAuth();
        Auth::requireAdmin();

        $question = trim($_POST['question'] ?? '');
        $status = $_POST['status'] ?? 'active';
        $options = array_filter(array_map('trim', $_POST['options'] ?? []));

        if (empty($question) || count($options) < 2) {
            $_SESSION['error'] = 'Question and at least 2 options are required.';
            header('Location: ' . APP_URL . '/admin/polls');
            exit;
        }

        $db = getDB();
        $stmt = $db->prepare("INSERT INTO polls (question, status, created_by) VALUES (?, ?, ?)");
        $stmt->execute([$question, $status, Auth::user()['id']]);
        $pollId = $db->lastInsertId();

        $stmt = $db->prepare("INSERT INTO poll_options (poll_id, option_text, display_order) VALUES (?, ?, ?)");
        foreach (array_values($options) as $i => $opt) {
            $stmt->execute([$pollId, $opt, $i + 1]);
        }

        $_SESSION['success'] = 'Poll created successfully!';
        header('Location: ' . APP_URL . '/admin/polls');
        exit;
    }

    public function viewIPs($pollId) {
        Auth::requireAuth();
        Auth::requireAdmin();
        $db = getDB();

        $stmt = $db->prepare("SELECT * FROM polls WHERE id = ?");
        $stmt->execute([$pollId]);
        $poll = $stmt->fetch();

        if (!$poll) {
            header('Location: ' . APP_URL . '/admin/polls');
            exit;
        }

        $voterIPs = VotingEngine::getActiveVoterIPs((int)$pollId);
        $user = Auth::user();
        require VIEWS_PATH . 'admin/view_ips.php';
    }

    public function releaseIP() {
        Auth::requireAuth();
        Auth::requireAdmin();

        $pollId = (int)($_POST['poll_id'] ?? 0);
        $ip = $_POST['ip_address'] ?? '';

        $result = VotingEngine::releaseIP($pollId, $ip);
        $_SESSION['message'] = $result['message'];
        header('Location: ' . APP_URL . '/admin/polls/' . $pollId . '/ips');
        exit;
    }

    /**
     * AJAX release IP - returns JSON with updated results
     */
    public function ajaxReleaseIP() {
        header('Content-Type: application/json');

        if (!Auth::check() || !Auth::isAdmin()) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
            exit;
        }

        $pollId = (int)($_POST['poll_id'] ?? 0);
        $ip = $_POST['ip_address'] ?? '';

        if (!$pollId || empty($ip)) {
            echo json_encode(['success' => false, 'message' => 'Invalid request.']);
            exit;
        }

        $result = VotingEngine::releaseIP($pollId, $ip);
        echo json_encode($result);
        exit;
    }

    public function voteHistory($pollId) {
        Auth::requireAuth();
        Auth::requireAdmin();
        $db = getDB();

        $stmt = $db->prepare("SELECT * FROM polls WHERE id = ?");
        $stmt->execute([$pollId]);
        $poll = $stmt->fetch();

        if (!$poll) {
            header('Location: ' . APP_URL . '/admin/polls');
            exit;
        }

        $history = VotingEngine::getVoteHistory((int)$pollId);
        $user = Auth::user();
        require VIEWS_PATH . 'admin/vote_history.php';
    }
}
