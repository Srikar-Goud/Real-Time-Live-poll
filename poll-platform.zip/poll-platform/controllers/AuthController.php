<?php
require_once __DIR__ . '/../core/Auth.php';

class AuthController {
    
    public function showLogin() {
        if (Auth::check()) {
            header('Location: ' . APP_URL . '/polls');
            exit;
        }
        require VIEWS_PATH . 'auth/login.php';
    }

    public function login() {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $error = '';

        if (empty($email) || empty($password)) {
            $error = 'Email and password are required.';
        } else {
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                Auth::login($user);
                $redirect = $user['role'] === 'admin' ? '/admin' : '/polls';
                header('Location: ' . APP_URL . $redirect);
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        }

        require VIEWS_PATH . 'auth/login.php';
    }

    public function showRegister() {
        if (Auth::check()) {
            header('Location: ' . APP_URL . '/polls');
            exit;
        }
        require VIEWS_PATH . 'auth/register.php';
    }

    public function register() {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $error = '';

        if (empty($name) || empty($email) || empty($password)) {
            $error = 'All fields are required.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } else {
            $db = getDB();
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email already registered.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')");
                $stmt->execute([$name, $email, $hash]);
                $userId = $db->lastInsertId();
                $user = ['id' => $userId, 'name' => $name, 'email' => $email, 'role' => 'user'];
                Auth::login($user);
                header('Location: ' . APP_URL . '/polls');
                exit;
            }
        }

        require VIEWS_PATH . 'auth/register.php';
    }

    public function logout() {
        Auth::logout();
        header('Location: ' . APP_URL . '/login');
        exit;
    }
}
