<?php
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/VotingEngine.php';

class PollController {

    public function index() {
        Auth::requireAuth();
        $db = getDB();
        $stmt = $db->query("SELECT p.*, u.name as creator_name, 
            (SELECT COUNT(*) FROM votes v WHERE v.poll_id = p.id AND v.is_active = 1) as vote_count
            FROM polls p LEFT JOIN users u ON p.created_by = u.id 
            WHERE p.status = 'active' ORDER BY p.created_at DESC");
        $polls = $stmt->fetchAll();
        $user = Auth::user();
        require VIEWS_PATH . 'polls/index.php';
    }

    public function show($id) {
        Auth::requireAuth();
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM polls WHERE id = ?");
        $stmt->execute([$id]);
        $poll = $stmt->fetch();

        if (!$poll) {
            header('Location: ' . APP_URL . '/polls');
            exit;
        }

        $stmt = $db->prepare("SELECT * FROM poll_options WHERE poll_id = ? ORDER BY display_order ASC");
        $stmt->execute([$id]);
        $options = $stmt->fetchAll();

        $ip = Auth::getIP();
        $hasVoted = VotingEngine::hasVoted((int)$id, $ip);
        $results = VotingEngine::getResults((int)$id);
        $user = Auth::user();

        require VIEWS_PATH . 'polls/show.php';
    }
}
