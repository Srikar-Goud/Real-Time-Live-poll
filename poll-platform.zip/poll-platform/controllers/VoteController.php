<?php
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/VotingEngine.php';

class VoteController {

    public function store() {
        Auth::requireAuth();
        $pollId = (int)($_POST['poll_id'] ?? 0);
        $optionId = (int)($_POST['option_id'] ?? 0);
        $ip = Auth::getIP();

        $result = VotingEngine::castVote($pollId, $optionId, $ip);
        header('Location: ' . APP_URL . '/polls/' . $pollId);
        exit;
    }

    /**
     * AJAX vote endpoint - returns JSON
     * Mandatory: no page reload
     */
    public function ajaxVote() {
        header('Content-Type: application/json');
        
        if (!Auth::check()) {
            echo json_encode(['success' => false, 'message' => 'Not authenticated.']);
            exit;
        }

        $pollId = (int)($_POST['poll_id'] ?? 0);
        $optionId = (int)($_POST['option_id'] ?? 0);
        $ip = Auth::getIP();

        if (!$pollId || !$optionId) {
            echo json_encode(['success' => false, 'message' => 'Invalid request.']);
            exit;
        }

        $result = VotingEngine::castVote($pollId, $optionId, $ip);
        echo json_encode($result);
        exit;
    }

    /**
     * AJAX results - returns JSON for real-time updates (~1 second polling)
     */
    public function ajaxResults($pollId) {
        header('Content-Type: application/json');
        
        if (!Auth::check()) {
            echo json_encode(['success' => false, 'message' => 'Not authenticated.']);
            exit;
        }

        $results = VotingEngine::getResults((int)$pollId);
        $ip = Auth::getIP();
        $hasVoted = VotingEngine::hasVoted((int)$pollId, $ip);
        
        echo json_encode([
            'success' => true,
            'results' => $results,
            'has_voted' => $hasVoted
        ]);
        exit;
    }

    public function results($id) {
        Auth::requireAuth();
        // Redirect to poll show page which includes results
        header('Location: ' . APP_URL . '/polls/' . $id);
        exit;
    }
}
