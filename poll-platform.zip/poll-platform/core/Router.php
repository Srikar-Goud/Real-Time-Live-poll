<?php
class Router {
    private $routes = [];

    public function get($path, $handler) {
        $this->routes['GET'][$path] = $handler;
    }

    public function post($path, $handler) {
        $this->routes['POST'][$path] = $handler;
    }

    public function dispatch() {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Remove base path
        $basePath = str_replace('/index.php', '', $_SERVER['SCRIPT_NAME']);
        $uri = str_replace($basePath, '', $uri);
        if (empty($uri)) $uri = '/';

        $params = [];
        $matched = null;

        if (isset($this->routes[$method])) {
            // Direct match
            if (isset($this->routes[$method][$uri])) {
                $matched = $this->routes[$method][$uri];
            } else {
                // Pattern match for {id} segments
                foreach ($this->routes[$method] as $route => $handler) {
                    $pattern = preg_replace('/\{[^}]+\}/', '([^/]+)', $route);
                    $pattern = '#^' . $pattern . '$#';
                    if (preg_match($pattern, $uri, $matches)) {
                        array_shift($matches);
                        $params = $matches;
                        $matched = $handler;
                        break;
                    }
                }
            }
        }

        if ($matched) {
            [$controllerName, $action] = explode('@', $matched);
            $controllerFile = CONTROLLERS_PATH . $controllerName . '.php';
            if (file_exists($controllerFile)) {
                require_once $controllerFile;
                $controller = new $controllerName();
                call_user_func_array([$controller, $action], $params);
            } else {
                http_response_code(404);
                echo "Controller not found: $controllerName";
            }
        } else {
            http_response_code(404);
            $this->render404();
        }
    }

    private function render404() {
        echo '<!DOCTYPE html><html><head><title>404</title></head><body><h1>404 - Page Not Found</h1><a href="' . APP_URL . '">Go Home</a></body></html>';
    }
}
