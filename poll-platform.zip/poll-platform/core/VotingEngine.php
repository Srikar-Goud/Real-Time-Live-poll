<?php
/**
 * VotingEngine - Core PHP voting logic (IP restriction, rollback, history)
 * This is the Core PHP layer handling all vote business logic.
 */
class VotingEngine {

    /**
     * Attempt to cast a vote. Returns result array.
     * Core PHP mandatory: IP-based restriction enforced here.
     */
    public static function castVote(int $pollId, int $optionId, string $ip): array {
        $db = getDB();

        // Check poll exists and is active
        $stmt = $db->prepare("SELECT * FROM polls WHERE id = ? AND status = 'active'");
        $stmt->execute([$pollId]);
        $poll = $stmt->fetch();
        if (!$poll) {
            return ['success' => false, 'message' => 'Poll not found or inactive.'];
        }

        // Check option belongs to this poll
        $stmt = $db->prepare("SELECT * FROM poll_options WHERE id = ? AND poll_id = ?");
        $stmt->execute([$optionId, $pollId]);
        $option = $stmt->fetch();
        if (!$option) {
            return ['success' => false, 'message' => 'Invalid option.'];
        }

        // Core PHP IP restriction: check if IP already has an ACTIVE vote on this poll
        $stmt = $db->prepare(
            "SELECT * FROM votes WHERE poll_id = ? AND ip_address = ? AND is_active = 1"
        );
        $stmt->execute([$pollId, $ip]);
        $existingVote = $stmt->fetch();

        if ($existingVote) {
            return [
                'success' => false,
                'message' => 'You have already voted on this poll from your IP address.',
                'already_voted' => true,
                'voted_option' => $existingVote['option_id']
            ];
        }

        // Insert vote
        $stmt = $db->prepare(
            "INSERT INTO votes (poll_id, option_id, ip_address, voted_at, is_active) VALUES (?, ?, ?, NOW(), 1)"
        );
        $stmt->execute([$pollId, $optionId, $ip]);

        // Return updated counts
        $counts = self::getResults($pollId);
        return [
            'success' => true,
            'message' => 'Vote recorded successfully!',
            'results' => $counts
        ];
    }

    /**
     * Get live poll results.
     */
    public static function getResults(int $pollId): array {
        $db = getDB();
        $stmt = $db->prepare(
            "SELECT po.id, po.option_text, COUNT(v.id) as vote_count
             FROM poll_options po
             LEFT JOIN votes v ON po.id = v.option_id AND v.is_active = 1
             WHERE po.poll_id = ?
             GROUP BY po.id, po.option_text
             ORDER BY po.id ASC"
        );
        $stmt->execute([$pollId]);
        $rows = $stmt->fetchAll();

        $total = array_sum(array_column($rows, 'vote_count'));
        foreach ($rows as &$row) {
            $row['percentage'] = $total > 0 ? round(($row['vote_count'] / $total) * 100, 1) : 0;
        }
        return ['options' => $rows, 'total' => $total];
    }

    /**
     * Release an IP's vote on a poll (Admin: rollback vote, allow re-voting)
     * Core PHP: vote is NOT deleted - marked inactive for audit trail.
     */
    public static function releaseIP(int $pollId, string $ip): array {
        $db = getDB();

        // Find active vote
        $stmt = $db->prepare(
            "SELECT * FROM votes WHERE poll_id = ? AND ip_address = ? AND is_active = 1"
        );
        $stmt->execute([$pollId, $ip]);
        $vote = $stmt->fetch();

        if (!$vote) {
            return ['success' => false, 'message' => 'No active vote found for this IP.'];
        }

        // Mark as released (not deleted - preserve audit)
        $stmt = $db->prepare(
            "UPDATE votes SET is_active = 0, released_at = NOW() WHERE id = ?"
        );
        $stmt->execute([$vote['id']]);

        $counts = self::getResults($pollId);
        return [
            'success' => true,
            'message' => "IP $ip has been released. Vote removed from count.",
            'results' => $counts
        ];
    }

    /**
     * Get vote history for a poll (for admin audit trail)
     */
    public static function getVoteHistory(int $pollId): array {
        $db = getDB();
        $stmt = $db->prepare(
            "SELECT v.*, po.option_text,
                    v.voted_at, v.released_at,
                    v.is_active
             FROM votes v
             JOIN poll_options po ON v.option_id = po.id
             WHERE v.poll_id = ?
             ORDER BY v.ip_address, v.voted_at ASC"
        );
        $stmt->execute([$pollId]);
        return $stmt->fetchAll();
    }

    /**
     * Get IPs that voted on a poll (active votes)
     */
    public static function getActiveVoterIPs(int $pollId): array {
        $db = getDB();
        $stmt = $db->prepare(
            "SELECT v.ip_address, po.option_text, v.voted_at
             FROM votes v
             JOIN poll_options po ON v.option_id = po.id
             WHERE v.poll_id = ? AND v.is_active = 1
             ORDER BY v.voted_at DESC"
        );
        $stmt->execute([$pollId]);
        return $stmt->fetchAll();
    }

    /**
     * Check if an IP has voted on a poll (active vote)
     */
    public static function hasVoted(int $pollId, string $ip): bool {
        $db = getDB();
        $stmt = $db->prepare(
            "SELECT id FROM votes WHERE poll_id = ? AND ip_address = ? AND is_active = 1"
        );
        $stmt->execute([$pollId, $ip]);
        return (bool) $stmt->fetch();
    }
}
