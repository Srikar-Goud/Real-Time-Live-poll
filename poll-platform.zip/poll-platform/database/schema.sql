-- Poll Platform Database Schema
-- Run this in MySQL to set up the database

CREATE DATABASE IF NOT EXISTS poll_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE poll_platform;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Polls table
CREATE TABLE IF NOT EXISTS polls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Poll options
CREATE TABLE IF NOT EXISTS poll_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    poll_id INT NOT NULL,
    option_text VARCHAR(255) NOT NULL,
    display_order INT DEFAULT 0,
    FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE
);

-- Votes table - Core PHP voting logic stores all votes here
-- is_active=1 means current active vote
-- is_active=0 means released by admin (kept for audit trail)
CREATE TABLE IF NOT EXISTS votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    poll_id INT NOT NULL,
    option_id INT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    voted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    released_at TIMESTAMP NULL,
    is_active TINYINT(1) DEFAULT 1,
    FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,
    FOREIGN KEY (option_id) REFERENCES poll_options(id) ON DELETE CASCADE,
    INDEX idx_poll_ip (poll_id, ip_address),
    INDEX idx_active (is_active)
);

-- Seed: default admin user (password: admin123)
INSERT IGNORE INTO users (name, email, password, role) VALUES 
('Admin', 'admin@poll.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Test User', 'user@poll.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');

-- Seed: sample polls
INSERT IGNORE INTO polls (id, question, status, created_by) VALUES 
(1, 'What is your favorite programming language?', 'active', 1),
(2, 'Which framework do you prefer for web development?', 'active', 1),
(3, 'How many hours do you code per day?', 'inactive', 1);

INSERT IGNORE INTO poll_options (poll_id, option_text, display_order) VALUES
(1, 'PHP', 1), (1, 'Python', 2), (1, 'JavaScript', 3), (1, 'Java', 4), (1, 'Go', 5),
(2, 'Laravel', 1), (2, 'Django', 2), (2, 'React', 3), (2, 'Vue.js', 4),
(3, '1-2 hours', 1), (3, '3-5 hours', 2), (3, '6-8 hours', 3), (3, '8+ hours', 4);
