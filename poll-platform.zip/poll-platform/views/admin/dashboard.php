<?php
$pageTitle = 'Admin Dashboard - ' . APP_NAME;
ob_start();
?>
<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold mb-1"><i class="bi bi-speedometer2 text-primary me-2"></i>Admin Dashboard</h4>
                <p class="text-muted mb-0">Welcome back, <?= htmlspecialchars($user['name']) ?></p>
            </div>
            <a href="<?= APP_URL ?>/admin/polls" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>Manage Polls
            </a>
        </div>
    </div>
</div>

<!-- Stats Row -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card stat-card text-center" style="background:linear-gradient(135deg,#4f46e5,#7c3aed); color:#fff;">
            <div class="stat-number"><?= $totalPolls ?></div>
            <div class="stat-label" style="color:rgba(255,255,255,.8);">Total Polls</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card text-center" style="background:linear-gradient(135deg,#10b981,#059669); color:#fff;">
            <div class="stat-number"><?= $activePolls ?></div>
            <div class="stat-label" style="color:rgba(255,255,255,.8);">Active Polls</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card text-center" style="background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff;">
            <div class="stat-number"><?= $totalVotes ?></div>
            <div class="stat-label" style="color:rgba(255,255,255,.8);">Total Votes</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card text-center" style="background:linear-gradient(135deg,#3b82f6,#2563eb); color:#fff;">
            <div class="stat-number"><?= $totalUsers ?></div>
            <div class="stat-label" style="color:rgba(255,255,255,.8);">Users</div>
        </div>
    </div>
</div>

<!-- Recent Polls -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center py-3">
        <h6 class="mb-0 fw-bold"><i class="bi bi-clock-history me-2 text-primary"></i>Recent Polls</h6>
        <a href="<?= APP_URL ?>/admin/polls" class="btn btn-sm btn-outline-primary">View All</a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Question</th>
                        <th>Status</th>
                        <th>Votes</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentPolls as $p): ?>
                    <tr>
                        <td class="ps-4">
                            <span class="fw-medium"><?= htmlspecialchars(substr($p['question'], 0, 60)) ?><?= strlen($p['question']) > 60 ? '...' : '' ?></span>
                        </td>
                        <td>
                            <?php if ($p['status'] === 'active'): ?>
                                <span class="badge-active">Active</span>
                            <?php else: ?>
                                <span class="badge-inactive">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= $p['vote_count'] ?></strong></td>
                        <td class="text-muted small"><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
                        <td>
                            <a href="<?= APP_URL ?>/polls/<?= $p['id'] ?>" class="btn btn-xs btn-sm btn-outline-secondary me-1" title="View">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="<?= APP_URL ?>/admin/polls/<?= $p['id'] ?>/ips" class="btn btn-sm btn-outline-warning me-1" title="View IPs">
                                <i class="bi bi-shield-lock"></i>
                            </a>
                            <a href="<?= APP_URL ?>/admin/vote-history/<?= $p['id'] ?>" class="btn btn-sm btn-outline-info" title="History">
                                <i class="bi bi-clock-history"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
require VIEWS_PATH . 'layout.php';
?>
