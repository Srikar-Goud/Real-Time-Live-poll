<?php
$pageTitle = 'Manage Polls - Admin';
ob_start();
?>
<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold mb-1"><i class="bi bi-collection-fill text-primary me-2"></i>Manage Polls</h4>
                <p class="text-muted mb-0">Create and manage all polls</p>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createPollModal">
                <i class="bi bi-plus-circle me-2"></i>Create Poll
            </button>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">#</th>
                        <th>Question</th>
                        <th>Status</th>
                        <th>Votes</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($polls)): ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted">No polls yet. Create one!</td></tr>
                    <?php endif; ?>
                    <?php foreach ($polls as $p): ?>
                    <tr>
                        <td class="ps-4 text-muted"><?= $p['id'] ?></td>
                        <td>
                            <span class="fw-medium"><?= htmlspecialchars(substr($p['question'], 0, 70)) ?><?= strlen($p['question']) > 70 ? '...' : '' ?></span>
                            <div class="text-muted small mt-1">By: <?= htmlspecialchars($p['creator_name'] ?? 'Unknown') ?></div>
                        </td>
                        <td>
                            <?php if ($p['status'] === 'active'): ?>
                                <span class="badge-active">Active</span>
                            <?php else: ?>
                                <span class="badge-inactive">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= $p['vote_count'] ?></strong>
                            <span class="text-muted small"> active</span>
                        </td>
                        <td class="text-muted small"><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="<?= APP_URL ?>/polls/<?= $p['id'] ?>" class="btn btn-outline-secondary" title="View Poll">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?= APP_URL ?>/admin/polls/<?= $p['id'] ?>/ips" class="btn btn-outline-warning" title="Manage IPs">
                                    <i class="bi bi-shield-lock"></i> IPs
                                </a>
                                <a href="<?= APP_URL ?>/admin/vote-history/<?= $p['id'] ?>" class="btn btn-outline-info" title="Vote History">
                                    <i class="bi bi-clock-history"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Create Poll Modal -->
<div class="modal fade" id="createPollModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold"><i class="bi bi-plus-circle text-primary me-2"></i>Create New Poll</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= APP_URL ?>/admin/polls/create">
                <div class="modal-body p-4">
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Poll Question</label>
                        <textarea name="question" class="form-control" rows="2" placeholder="e.g. What is your favorite programming language?" required></textarea>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Status</label>
                        <select name="status" class="form-select">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Options <small class="text-muted">(min. 2 required)</small></label>
                        <div id="optionsContainer">
                            <div class="input-group mb-2">
                                <span class="input-group-text text-muted small">1</span>
                                <input type="text" name="options[]" class="form-control" placeholder="Option 1" required>
                            </div>
                            <div class="input-group mb-2">
                                <span class="input-group-text text-muted small">2</span>
                                <input type="text" name="options[]" class="form-control" placeholder="Option 2" required>
                            </div>
                            <div class="input-group mb-2">
                                <span class="input-group-text text-muted small">3</span>
                                <input type="text" name="options[]" class="form-control" placeholder="Option 3 (optional)">
                            </div>
                            <div class="input-group mb-2">
                                <span class="input-group-text text-muted small">4</span>
                                <input type="text" name="options[]" class="form-control" placeholder="Option 4 (optional)">
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-secondary mt-1" id="addOption">
                            <i class="bi bi-plus me-1"></i>Add Option
                        </button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary fw-semibold px-4">
                        <i class="bi bi-check-circle me-2"></i>Create Poll
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let optCount = 4;
$('#addOption').on('click', function() {
    optCount++;
    const html = `<div class="input-group mb-2">
        <span class="input-group-text text-muted small">${optCount}</span>
        <input type="text" name="options[]" class="form-control" placeholder="Option ${optCount} (optional)">
        <button type="button" class="btn btn-outline-danger remove-opt"><i class="bi bi-x"></i></button>
    </div>`;
    $('#optionsContainer').append(html);
});
$(document).on('click', '.remove-opt', function() {
    $(this).closest('.input-group').remove();
});
</script>
<?php
$content = ob_get_clean();
require VIEWS_PATH . 'layout.php';
?>
