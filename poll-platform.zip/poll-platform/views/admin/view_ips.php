<?php
$pageTitle = 'Manage IPs - ' . htmlspecialchars($poll['question']);
ob_start();
?>
<div class="mb-3">
    <a href="<?= APP_URL ?>/admin/polls" class="btn btn-sm btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Back to Polls
    </a>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-header py-3">
                <h5 class="mb-1 fw-bold"><i class="bi bi-shield-lock text-warning me-2"></i>IP Voter Management</h5>
                <p class="text-muted mb-0 small"><?= htmlspecialchars($poll['question']) ?></p>
            </div>
            <div class="card-body">
                <div class="alert alert-info py-2 mb-4">
                    <i class="bi bi-info-circle me-2"></i>
                    <strong>Release an IP</strong> to remove their vote and allow them to vote again. 
                    The original vote is preserved in the audit log.
                </div>

                <?php if (empty($voterIPs)): ?>
                <div class="text-center py-4 text-muted">
                    <i class="bi bi-people" style="font-size:2.5rem;"></i>
                    <p class="mt-2">No votes recorded yet for this poll.</p>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>IP Address</th>
                                <th>Voted For</th>
                                <th>Voted At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="ipTable">
                            <?php foreach ($voterIPs as $voter): ?>
                            <tr id="ip_row_<?= md5($voter['ip_address']) ?>">
                                <td><span class="ip-tag"><?= htmlspecialchars($voter['ip_address']) ?></span></td>
                                <td class="fw-medium"><?= htmlspecialchars($voter['option_text']) ?></td>
                                <td class="text-muted small"><?= date('M d, Y H:i:s', strtotime($voter['voted_at'])) ?></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger release-ip-btn"
                                            data-poll="<?= $poll['id'] ?>"
                                            data-ip="<?= htmlspecialchars($voter['ip_address']) ?>"
                                            data-row="ip_row_<?= md5($voter['ip_address']) ?>">
                                        <i class="bi bi-unlock me-1"></i>Release IP
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Live Results after Release -->
        <div class="card">
            <div class="card-header py-3 d-flex justify-content-between">
                <h6 class="mb-0 fw-bold"><i class="bi bi-bar-chart me-2 text-primary"></i>Current Live Results</h6>
                <span class="live-badge"><span class="dot"></span> Updates in real-time</span>
            </div>
            <div class="card-body" id="adminResults">
                <?php
                $results = \VotingEngine::getResults((int)$poll['id']);
                foreach ($results['options'] as $opt):
                ?>
                <div class="results-row" id="admin_result_<?= $opt['id'] ?>">
                    <div class="option-label">
                        <span><?= htmlspecialchars($opt['option_text']) ?></span>
                        <span class="text-muted small">
                            <span class="vote-count"><?= $opt['vote_count'] ?></span> votes
                            (<span class="vote-pct"><?= $opt['percentage'] ?></span>%)
                        </span>
                    </div>
                    <div class="progress mb-3">
                        <div class="progress-bar" style="width: <?= $opt['percentage'] ?>%"></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <div class="text-muted small text-end">Total: <strong id="adminTotal"><?= $results['total'] ?></strong> votes</div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header py-3">
                <h6 class="fw-bold mb-0"><i class="bi bi-info-circle me-2"></i>Quick Info</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <small class="text-muted d-block">Poll ID</small>
                    <strong>#<?= $poll['id'] ?></strong>
                </div>
                <div class="mb-3">
                    <small class="text-muted d-block">Status</small>
                    <?php if ($poll['status'] === 'active'): ?>
                        <span class="badge-active">Active</span>
                    <?php else: ?>
                        <span class="badge-inactive">Inactive</span>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <small class="text-muted d-block">Active Voters</small>
                    <strong id="activeVoterCount"><?= count($voterIPs) ?></strong>
                </div>
                <div class="mt-4">
                    <a href="<?= APP_URL ?>/admin/vote-history/<?= $poll['id'] ?>" class="btn btn-outline-info w-100 mb-2">
                        <i class="bi bi-clock-history me-2"></i>View Full Vote History
                    </a>
                    <a href="<?= APP_URL ?>/polls/<?= $poll['id'] ?>" class="btn btn-outline-primary w-100">
                        <i class="bi bi-eye me-2"></i>View Poll Page
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Release confirmation modal -->
<div class="modal fade" id="releaseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-unlock-fill text-warning me-2"></i>Release IP</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to release IP <strong id="releaseIPDisplay"></strong>?</p>
                <p class="text-muted small">This will remove their vote from the count and allow them to vote again. The original vote will be preserved in the audit log.</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-danger" id="confirmRelease">
                    <i class="bi bi-unlock me-2"></i>Confirm Release
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$extraScripts = <<<'SCRIPT'
<script>
const APP_URL_JS = document.querySelector('meta[name="app-url"]')?.content || window.location.origin;

let pendingRelease = null;

$(document).on('click', '.release-ip-btn', function() {
    const pollId = $(this).data('poll');
    const ip = $(this).data('ip');
    const row = $(this).data('row');
    pendingRelease = { pollId, ip, row };
    $('#releaseIPDisplay').text(ip);
    new bootstrap.Modal('#releaseModal').show();
});

$('#confirmRelease').on('click', function() {
    if (!pendingRelease) return;
    const { pollId, ip, row } = pendingRelease;
    $(this).prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Releasing...');

    $.ajax({
        url: window.location.origin + (window.location.pathname.includes('/poll-platform') ? '/poll-platform' : '') + '/ajax/release-ip',
        method: 'POST',
        data: { poll_id: pollId, ip_address: ip },
        dataType: 'json',
        success: function(res) {
            bootstrap.Modal.getInstance('#releaseModal').hide();
            if (res.success) {
                // Remove row from table (no page reload)
                $('#' + row).fadeOut(400, function() { $(this).remove(); });
                updateAdminResults(res.results);
                showToast(res.message, 'success');
                // Update voter count
                const count = parseInt($('#activeVoterCount').text()) - 1;
                $('#activeVoterCount').text(Math.max(0, count));
            } else {
                showToast(res.message, 'danger');
            }
            $('#confirmRelease').prop('disabled', false).html('<i class="bi bi-unlock me-2"></i>Confirm Release');
        },
        error: function() {
            showToast('Error releasing IP.', 'danger');
            $('#confirmRelease').prop('disabled', false).html('<i class="bi bi-unlock me-2"></i>Confirm Release');
        }
    });
});

function updateAdminResults(results) {
    if (!results) return;
    $('#adminTotal').text(results.total);
    results.options.forEach(function(opt) {
        const row = $('#admin_result_' + opt.id);
        if (row.length) {
            row.find('.vote-count').text(opt.vote_count);
            row.find('.vote-pct').text(opt.percentage);
            row.find('.progress-bar').css('width', opt.percentage + '%');
        }
    });
}

function showToast(msg, type) {
    const colors = { success: '#10b981', danger: '#ef4444', info: '#3b82f6' };
    const toast = $('<div class="alert-flash alert py-2 px-3" style="background:' + (colors[type]||'#333') + ';color:#fff;border:none;border-radius:8px;">' + msg + '</div>');
    $('body').append(toast);
    setTimeout(() => toast.fadeOut(400, () => toast.remove()), 3000);
}

// Live results refresh
setInterval(function() {
    const pollId = <?= $poll['id'] ?>;
    const baseUrl = window.location.href.includes('/poll-platform') ? '/poll-platform' : '';
    $.getJSON(window.location.origin + baseUrl + '/ajax/results/' + pollId, function(res) {
        if (res.success) updateAdminResults(res.results);
    });
}, 1000);
</script>
SCRIPT;
$content = ob_get_clean();
require VIEWS_PATH . 'layout.php';
?>
