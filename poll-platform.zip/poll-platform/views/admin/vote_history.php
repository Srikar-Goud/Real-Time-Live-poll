<?php
$pageTitle = 'Vote History - ' . htmlspecialchars($poll['question']);

// Group history by IP for timeline
$byIP = [];
foreach ($history as $vote) {
    $byIP[$vote['ip_address']][] = $vote;
}
ob_start();
?>
<div class="mb-3">
    <a href="<?= APP_URL ?>/admin/polls/<?= $poll['id'] ?>/ips" class="btn btn-sm btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Back to IP Management
    </a>
</div>

<div class="card mb-4">
    <div class="card-header py-3">
        <h5 class="mb-1 fw-bold"><i class="bi bi-clock-history text-info me-2"></i>Full Vote History & Audit Trail</h5>
        <p class="text-muted mb-0 small"><?= htmlspecialchars($poll['question']) ?></p>
    </div>
    <div class="card-body">
        <div class="alert alert-light border py-2 mb-4 small">
            <i class="bi bi-shield-check text-success me-2"></i>
            All votes are preserved for auditing. Released votes (🔓) show when the IP was released and allowed to re-vote. 
            History shows: <strong>Original vote → Released → New vote</strong>
        </div>

        <?php if (empty($history)): ?>
        <div class="text-center py-4 text-muted">
            <i class="bi bi-inbox" style="font-size:2rem;"></i>
            <p class="mt-2">No vote history for this poll.</p>
        </div>
        <?php else: ?>

        <!-- Summary Table -->
        <h6 class="fw-bold mb-3">All Vote Records</h6>
        <div class="table-responsive mb-4">
            <table class="table table-sm table-hover">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>IP Address</th>
                        <th>Voted For</th>
                        <th>Status</th>
                        <th>Voted At</th>
                        <th>Released At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($history as $i => $v): ?>
                    <tr class="<?= $v['is_active'] ? '' : 'table-warning' ?>">
                        <td class="text-muted"><?= $i + 1 ?></td>
                        <td><span class="ip-tag"><?= htmlspecialchars($v['ip_address']) ?></span></td>
                        <td><?= htmlspecialchars($v['option_text']) ?></td>
                        <td>
                            <?php if ($v['is_active']): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Released</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-muted small"><?= date('M d, Y H:i:s', strtotime($v['voted_at'])) ?></td>
                        <td class="text-muted small">
                            <?= $v['released_at'] ? date('M d, Y H:i:s', strtotime($v['released_at'])) : '—' ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Timeline by IP -->
        <h6 class="fw-bold mb-3">Timeline by IP Address</h6>
        <?php foreach ($byIP as $ip => $votes): ?>
        <div class="card mb-3 border-0 bg-light">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <i class="bi bi-geo-alt-fill text-primary me-2"></i>
                    <span class="ip-tag me-2"><?= htmlspecialchars($ip) ?></span>
                    <small class="text-muted"><?= count($votes) ?> vote record(s)</small>
                </div>
                <div class="history-timeline">
                    <?php foreach ($votes as $j => $v): ?>
                    <div class="timeline-item <?= !$v['is_active'] ? 'released' : '' ?>">
                        <div class="p-3 bg-white rounded border" style="margin-left:10px;">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <?php if ($j === 0): ?>
                                        <span class="badge bg-primary mb-1">Original Vote</span>
                                    <?php elseif (!$v['is_active']): ?>
                                        <span class="badge bg-secondary mb-1">Vote (Released)</span>
                                    <?php else: ?>
                                        <span class="badge bg-success mb-1">Re-Vote</span>
                                    <?php endif; ?>
                                    <div class="fw-medium"><?= htmlspecialchars($v['option_text']) ?></div>
                                </div>
                                <div class="text-end text-muted small">
                                    <div><i class="bi bi-clock me-1"></i><?= date('M d, H:i:s', strtotime($v['voted_at'])) ?></div>
                                    <?php if ($v['released_at']): ?>
                                    <div class="text-danger mt-1"><i class="bi bi-unlock me-1"></i>Released: <?= date('M d, H:i:s', strtotime($v['released_at'])) ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php if (!$v['is_active'] && isset($votes[$j + 1])): ?>
                        <div class="text-center my-1 text-danger small">
                            <i class="bi bi-arrow-down"></i> IP Released &mdash; Re-voting allowed
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <?php endif; ?>
    </div>
</div>
<?php
$content = ob_get_clean();
require VIEWS_PATH . 'layout.php';
?>
