<?php
$pageTitle = 'Register - ' . APP_NAME;
ob_start();
?>
<div class="row justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="col-md-5 col-lg-4">
        <div class="text-center mb-4">
            <div style="font-size:3rem; color:#4f46e5;"><i class="bi bi-person-plus-fill"></i></div>
            <h2 class="fw-bold mt-2">Create Account</h2>
            <p class="text-muted">Join LivePoll to start voting</p>
        </div>
        <div class="card p-4">
            <?php if (!empty($error)): ?>
            <div class="alert alert-danger py-2">
                <i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>
            <form method="POST" action="<?= APP_URL ?>/register">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Full Name</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" name="name" class="form-control" placeholder="John Doe"
                               value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Email</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" name="email" class="form-control" placeholder="you@example.com"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" name="password" class="form-control" placeholder="Min 6 characters" required>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-semibold">Confirm Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                    <i class="bi bi-person-check me-2"></i>Create Account
                </button>
            </form>
            <hr>
            <p class="text-center text-muted mb-0 small">
                Already have an account? <a href="<?= APP_URL ?>/login" class="fw-semibold">Sign In</a>
            </p>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
require VIEWS_PATH . 'layout.php';
?>
