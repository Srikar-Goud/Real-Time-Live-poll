<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? APP_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-dark: #3730a3;
            --success: #10b981;
            --danger: #ef4444;
            --bg: #f8fafc;
            --card: #ffffff;
            --border: #e2e8f0;
            --text: #1e293b;
            --muted: #64748b;
        }
        body { background: var(--bg); color: var(--text); font-family: 'Segoe UI', system-ui, sans-serif; }
        .navbar { background: var(--primary) !important; box-shadow: 0 2px 10px rgba(79,70,229,.3); }
        .navbar-brand { font-weight: 700; font-size: 1.4rem; color: #fff !important; }
        .navbar-brand span { color: #a5b4fc; }
        .nav-link { color: rgba(255,255,255,.85) !important; font-weight: 500; }
        .nav-link:hover, .nav-link.active { color: #fff !important; }
        .card { border: 1px solid var(--border); border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,.06); }
        .card-header { background: transparent; border-bottom: 1px solid var(--border); font-weight: 600; }
        .btn-primary { background: var(--primary); border-color: var(--primary); }
        .btn-primary:hover { background: var(--primary-dark); border-color: var(--primary-dark); }
        .badge-active { background: #d1fae5; color: #065f46; border-radius: 20px; padding: 4px 10px; font-size:.75rem; font-weight:600; }
        .badge-inactive { background: #fee2e2; color: #991b1b; border-radius: 20px; padding: 4px 10px; font-size:.75rem; font-weight:600; }
        .progress { height: 10px; border-radius: 10px; }
        .progress-bar { background: var(--primary); border-radius: 10px; transition: width 0.6s ease; }
        .vote-option { border: 2px solid var(--border); border-radius: 10px; padding: 14px 18px; cursor: pointer; transition: all .2s; margin-bottom: 10px; }
        .vote-option:hover { border-color: var(--primary); background: #eef2ff; }
        .vote-option.selected { border-color: var(--primary); background: #eef2ff; }
        .vote-option input[type=radio] { margin-right: 10px; accent-color: var(--primary); }
        .results-row { margin-bottom: 16px; }
        .results-row .option-label { font-weight: 500; margin-bottom: 4px; display: flex; justify-content: space-between; }
        .live-badge { display: inline-flex; align-items: center; gap: 6px; background: #fee2e2; color: #dc2626; border-radius: 20px; padding: 4px 12px; font-size: .8rem; font-weight: 600; }
        .live-badge .dot { width: 8px; height: 8px; background: #dc2626; border-radius: 50%; animation: pulse 1s infinite; }
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.6;transform:scale(1.3)} }
        .sidebar-link { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 8px; color: var(--text); text-decoration: none; font-weight: 500; transition: background .15s; }
        .sidebar-link:hover, .sidebar-link.active { background: #eef2ff; color: var(--primary); }
        .sidebar-link i { font-size: 1.1rem; }
        .stat-card { border-radius: 12px; padding: 20px; }
        .stat-card .stat-number { font-size: 2rem; font-weight: 700; }
        .stat-card .stat-label { color: var(--muted); font-size: .9rem; }
        .ip-tag { background: #f1f5f9; border: 1px solid var(--border); border-radius: 6px; padding: 4px 10px; font-family: monospace; font-size: .85rem; display: inline-block; }
        .history-timeline { position: relative; padding-left: 20px; }
        .history-timeline::before { content:''; position:absolute; left:6px; top:0; bottom:0; width:2px; background:var(--border); }
        .timeline-item { position: relative; margin-bottom: 16px; }
        .timeline-item::before { content:''; position:absolute; left:-16px; top:6px; width:10px; height:10px; border-radius:50%; background:var(--primary); border:2px solid #fff; box-shadow:0 0 0 2px var(--primary); }
        .timeline-item.released::before { background: var(--danger); box-shadow:0 0 0 2px var(--danger); }
        .alert-flash { position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px; animation: slideIn .3s ease; }
        @keyframes slideIn { from{transform:translateX(100%);opacity:0} to{transform:translateX(0);opacity:1} }
        @media(max-width:768px) { .sidebar { display:none; } }
    </style>
    <?= $extraStyles ?? '' ?>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid px-4">
        <a class="navbar-brand" href="<?= APP_URL ?>/polls">
            <i class="bi bi-bar-chart-fill me-2"></i>Live<span>Poll</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-center gap-1">
                <?php if (Auth::check()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= APP_URL ?>/polls">
                            <i class="bi bi-collection me-1"></i>Polls
                        </a>
                    </li>
                    <?php if (Auth::isAdmin()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= APP_URL ?>/admin">
                            <i class="bi bi-speedometer2 me-1"></i>Admin
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <span class="nav-link text-white-50">
                            <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars(Auth::user()['name']) ?>
                        </span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-sm btn-outline-light ms-1 px-3" href="<?= APP_URL ?>/logout">
                            <i class="bi bi-box-arrow-right me-1"></i>Logout
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/login">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/register">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['success'])): ?>
<div class="alert-flash alert alert-success alert-dismissible" id="flashMsg">
    <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_SESSION['success']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['success']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
<div class="alert-flash alert alert-danger alert-dismissible" id="flashMsg">
    <i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($_SESSION['error']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['error']); endif; ?>

<?php if (isset($_SESSION['message'])): ?>
<div class="alert-flash alert alert-info alert-dismissible" id="flashMsg">
    <i class="bi bi-info-circle me-2"></i><?= htmlspecialchars($_SESSION['message']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['message']); endif; ?>

<div class="container-fluid py-4 px-4">
    <?= $content ?? '' ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
    // Auto-dismiss flash messages
    setTimeout(() => { $('#flashMsg').fadeOut(500); }, 4000);
</script>
<?= $extraScripts ?? '' ?>
</body>
</html>
