<?php
$pageTitle = 'Active Polls - ' . APP_NAME;
ob_start();
?>
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-bold mb-1"><i class="bi bi-collection-fill text-primary me-2"></i>Active Polls</h4>
                <p class="text-muted mb-0">Click a poll to view and vote</p>
            </div>
            <span class="live-badge">
                <span class="dot"></span> Live
            </span>
        </div>

        <?php if (empty($polls)): ?>
        <div class="card text-center py-5">
            <div class="text-muted">
                <i class="bi bi-inbox" style="font-size:3rem;"></i>
                <p class="mt-3 mb-0">No active polls at the moment.</p>
                <?php if (Auth::isAdmin()): ?>
                <a href="<?= APP_URL ?>/admin/polls" class="btn btn-primary mt-3">Create a Poll</a>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="row g-3">
            <?php foreach ($polls as $poll): ?>
            <div class="col-md-6 col-lg-4">
                <a href="<?= APP_URL ?>/polls/<?= $poll['id'] ?>" class="text-decoration-none">
                    <div class="card h-100 poll-card" style="transition:all .2s; cursor:pointer;">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <span class="badge-active">Active</span>
                                <small class="text-muted"><?= date('M d, Y', strtotime($poll['created_at'])) ?></small>
                            </div>
                            <h6 class="fw-semibold text-dark mb-3" style="line-height:1.4;">
                                <?= htmlspecialchars($poll['question']) ?>
                            </h6>
                            <div class="d-flex align-items-center justify-content-between mt-auto">
                                <span class="text-muted small">
                                    <i class="bi bi-people me-1"></i><?= $poll['vote_count'] ?> votes
                                </span>
                                <span class="btn btn-sm btn-outline-primary">
                                    Vote <i class="bi bi-arrow-right ms-1"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.poll-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(79,70,229,.15) !important; border-color: #c7d2fe !important; }
</style>
<?php
$content = ob_get_clean();
require VIEWS_PATH . 'layout.php';
?>
