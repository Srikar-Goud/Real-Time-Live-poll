<?php
$pageTitle = htmlspecialchars($poll['question']) . ' - ' . APP_NAME;
$pollId = $poll['id'];
$userIP = Auth::getIP();
ob_start();
?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="mb-3">
            <a href="<?= APP_URL ?>/polls" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-arrow-left me-1"></i>Back to Polls
            </a>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center py-3">
                <h5 class="mb-0 fw-bold"><?= htmlspecialchars($poll['question']) ?></h5>
                <span class="live-badge">
                    <span class="dot"></span> Live Results
                </span>
            </div>
            <div class="card-body p-4">

                <?php if ($poll['status'] !== 'active'): ?>
                <div class="alert alert-warning">
                    <i class="bi bi-pause-circle me-2"></i>This poll is currently inactive.
                </div>
                <?php endif; ?>

                <!-- Vote Form (shown when not voted) -->
                <div id="voteSection" <?= $hasVoted ? 'style="display:none;"' : '' ?>>
                    <p class="text-muted mb-4">Select an option below and submit your vote. <strong>One vote per IP address.</strong></p>
                    <form id="voteForm">
                        <input type="hidden" name="poll_id" value="<?= $pollId ?>">
                        <?php foreach ($options as $opt): ?>
                        <label class="vote-option d-block" for="opt_<?= $opt['id'] ?>">
                            <input type="radio" name="option_id" id="opt_<?= $opt['id'] ?>" value="<?= $opt['id'] ?>" required>
                            <?= htmlspecialchars($opt['option_text']) ?>
                        </label>
                        <?php endforeach; ?>
                        <button type="submit" id="submitVote" class="btn btn-primary mt-3 px-4 py-2 fw-semibold"
                                <?= $poll['status'] !== 'active' ? 'disabled' : '' ?>>
                            <i class="bi bi-check2-circle me-2"></i>Submit Vote
                        </button>
                    </form>
                    <div id="voteMsg" class="mt-3"></div>
                </div>

                <!-- Already voted message -->
                <div id="votedMessage" <?= !$hasVoted ? 'style="display:none;"' : '' ?>>
                    <div class="alert alert-success d-flex align-items-center">
                        <i class="bi bi-patch-check-fill me-2 fs-5"></i>
                        <div>
                            <strong>You've already voted on this poll.</strong>
                            <div class="small mt-1">Your vote has been recorded from IP: <span class="ip-tag"><?= htmlspecialchars($userIP) ?></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Real-Time Results Card -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center py-3">
                <h6 class="mb-0 fw-bold"><i class="bi bi-bar-chart me-2 text-primary"></i>Live Results</h6>
                <small class="text-muted">
                    <span id="totalVotes"><?= $results['total'] ?></span> total votes
                    &bull; Updates in <span id="countdown">1</span>s
                </small>
            </div>
            <div class="card-body p-4" id="resultsContainer">
                <?php foreach ($results['options'] as $opt): ?>
                <div class="results-row" id="result_<?= $opt['id'] ?>">
                    <div class="option-label">
                        <span><?= htmlspecialchars($opt['option_text']) ?></span>
                        <span class="text-muted small">
                            <span class="vote-count"><?= $opt['vote_count'] ?></span> votes
                            (<span class="vote-pct"><?= $opt['percentage'] ?></span>%)
                        </span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" 
                             style="width: <?= $opt['percentage'] ?>%"
                             data-option-id="<?= $opt['id'] ?>">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php
$extraScripts = <<<SCRIPT
<script>
const POLL_ID = <?= $pollId ?>;
const APP_URL = '<?= APP_URL ?>';
let pollInterval;
let countdownInterval;
let countdown = 1;

// Handle vote form submission via AJAX (no page reload)
$('#voteForm').on('submit', function(e) {
    e.preventDefault();
    const optionId = $('input[name="option_id"]:checked').val();
    if (!optionId) {
        showVoteMsg('Please select an option.', 'warning');
        return;
    }

    $('#submitVote').prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Submitting...');

    $.ajax({
        url: APP_URL + '/ajax/vote',
        method: 'POST',
        data: { poll_id: POLL_ID, option_id: optionId },
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                $('#voteSection').fadeOut(300, function() {
                    $('#votedMessage').fadeIn(300);
                });
                updateResults(res.results);
                showToast('Vote submitted successfully!', 'success');
            } else if (res.already_voted) {
                $('#voteSection').fadeOut(300, function() {
                    $('#votedMessage').fadeIn(300);
                });
                showToast(res.message, 'info');
            } else {
                showVoteMsg(res.message, 'danger');
                $('#submitVote').prop('disabled', false).html('<i class="bi bi-check2-circle me-2"></i>Submit Vote');
            }
        },
        error: function() {
            showVoteMsg('An error occurred. Please try again.', 'danger');
            $('#submitVote').prop('disabled', false).html('<i class="bi bi-check2-circle me-2"></i>Submit Vote');
        }
    });
});

// Real-time results polling (every ~1 second as required)
function startLivePolling() {
    pollInterval = setInterval(fetchResults, 1000);
    startCountdown();
}

function startCountdown() {
    countdown = 1;
    clearInterval(countdownInterval);
    countdownInterval = setInterval(function() {
        countdown--;
        if (countdown <= 0) countdown = 1;
        $('#countdown').text(countdown);
    }, 1000);
}

function fetchResults() {
    $.ajax({
        url: APP_URL + '/ajax/results/' + POLL_ID,
        method: 'GET',
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                updateResults(res.results);
                if (res.has_voted) {
                    $('#voteSection').hide();
                    $('#votedMessage').show();
                }
            }
        }
    });
}

function updateResults(results) {
    if (!results) return;
    $('#totalVotes').text(results.total);
    results.options.forEach(function(opt) {
        const row = $('#result_' + opt.id);
        if (row.length) {
            row.find('.vote-count').text(opt.vote_count);
            row.find('.vote-pct').text(opt.percentage);
            row.find('.progress-bar').css('width', opt.percentage + '%');
        }
    });
}

function showVoteMsg(msg, type) {
    $('#voteMsg').html('<div class="alert alert-' + type + ' py-2 mb-0"><i class="bi bi-info-circle me-2"></i>' + msg + '</div>');
}

function showToast(msg, type) {
    const colors = { success: '#10b981', danger: '#ef4444', info: '#3b82f6' };
    const toast = $('<div class="alert-flash alert py-2 px-3" style="background:' + colors[type] + ';color:#fff;border:none;">' + msg + '</div>');
    $('body').append(toast);
    setTimeout(() => toast.fadeOut(400, () => toast.remove()), 3000);
}

// Highlight selected option
$(document).on('change', 'input[name="option_id"]', function() {
    $('.vote-option').removeClass('selected');
    $(this).closest('.vote-option').addClass('selected');
});

// Start live polling on load
$(document).ready(function() {
    startLivePolling();
});

// Clean up on page leave
$(window).on('beforeunload', function() {
    clearInterval(pollInterval);
    clearInterval(countdownInterval);
});
</script>
SCRIPT;
$content = ob_get_clean();
require VIEWS_PATH . 'layout.php';
?>
